#pragma once

BOOL SharedUserData_KernelDebugger();