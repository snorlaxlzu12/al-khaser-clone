#pragma once

BOOL ModuleBoundsHookCheck();