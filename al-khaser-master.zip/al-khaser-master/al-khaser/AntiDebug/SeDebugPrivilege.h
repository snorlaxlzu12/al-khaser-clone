#pragma once

BOOL CanOpenCsrss();
