#pragma once

BOOL IsDebuggerPresentAPI();