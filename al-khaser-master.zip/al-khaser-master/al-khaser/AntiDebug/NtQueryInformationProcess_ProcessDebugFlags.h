#pragma once

BOOL NtQueryInformationProcess_ProcessDebugFlags();