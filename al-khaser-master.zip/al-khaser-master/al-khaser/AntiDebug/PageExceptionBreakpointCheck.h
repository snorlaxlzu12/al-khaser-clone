#pragma once

void PageExceptionInitialEnum();
BOOL PageExceptionBreakpointCheck();
