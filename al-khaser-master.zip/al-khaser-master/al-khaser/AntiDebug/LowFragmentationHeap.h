#pragma once

BOOL
LowFragmentationHeap(
	VOID
);