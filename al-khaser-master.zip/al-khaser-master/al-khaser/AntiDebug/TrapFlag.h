#pragma once

BOOL TrapFlag();