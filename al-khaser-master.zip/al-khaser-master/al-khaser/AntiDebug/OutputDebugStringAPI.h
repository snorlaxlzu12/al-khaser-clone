#pragma once

BOOL OutputDebugStringAPI();
