#pragma once

BOOL HeapFlags();