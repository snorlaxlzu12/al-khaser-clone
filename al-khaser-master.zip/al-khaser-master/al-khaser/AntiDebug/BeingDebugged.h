#pragma once

BOOL IsDebuggerPresentPEB();
