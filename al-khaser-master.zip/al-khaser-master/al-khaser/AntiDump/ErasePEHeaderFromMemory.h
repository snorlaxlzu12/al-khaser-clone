#pragma once

VOID ErasePEHeaderFromMemory();