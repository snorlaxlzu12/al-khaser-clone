#pragma once

VOID SizeOfImage();