#pragma once

VOID kvm_reg_keys();
VOID kvm_files();
BOOL kvm_dir();
