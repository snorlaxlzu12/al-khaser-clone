#pragma once

BOOL check_hyperv_driver_objects();
BOOL check_hyperv_global_objects();
