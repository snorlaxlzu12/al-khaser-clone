#pragma once

VOID vmware_reg_key_value();
VOID vmware_reg_keys();
VOID vmware_files();
BOOL vmware_dir();
VOID vmware_mac();
BOOL vmware_adapter_name();
VOID vmware_devices();
VOID vmware_processes();
BOOL vmware_firmware_SMBIOS();
BOOL vmware_firmware_ACPI();