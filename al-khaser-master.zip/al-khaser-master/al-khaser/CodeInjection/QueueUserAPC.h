#pragma once

BOOL QueueUserAPC_Injection();

