#pragma once

BOOL RtlCreateUserThread_Injection();
