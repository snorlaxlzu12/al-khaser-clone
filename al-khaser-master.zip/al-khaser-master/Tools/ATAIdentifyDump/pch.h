#ifndef PCH_H
#define PCH_H

#include <Windows.h>
#include <ntddscsi.h>
#include <stdio.h>
#include "IdentifyDeviceData.h"

#endif // PCH_H